const ENV = {
  STARTER_KIT_SERVER_URL: "https://yogi-2020-server.eu-gb.mybluemix.net",
};

export default ENV;
